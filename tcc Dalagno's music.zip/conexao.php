<?php

    $dbHost = 'Localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName = 'dalagnol';
    
    $conexao = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);

    if($conexao->conect_errno)
    {
        echo "Erro";
    }
    else
    {
        echo "Conexáo efetuada";
    }

?>